                       ╔╗╔╗╔╗
                       ║║║║║║
                       ║║║║║╠══╦═╦═╗╔╦═╗╔══╗
                       ║╚╝╚╝║╔╗║╔╣╔╗╬╣╔╗╣╔╗║
                       ╚╗╔╗╔╣╔╗║║║║║║║║║║╚╝║
                        ╚╝╚╝╚╝╚╩╝╚╝╚╩╩╝╚╩═╗║
                                        ╔═╝║
                                        ╚══╝

Unzip before using!!!
If you have some antimalware software wich has Ransomware protection it is recomended to disable protection for the safe because deleting the original folder after encrypting and deleting the encrypted folder after decrypting will dont work.